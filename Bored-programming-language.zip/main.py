import time,random, os, sys, requests

Mainfile = open("Start.bor", "r")
MainFileLines = Mainfile.readlines()
CountedLines = 0

ServicesImported = []

VariableDB = []
FuncDB = [] 
FuncLines = []
IfStateDB = []
IfStateLines = []
IfElseLines = []

def Execute_File(Sometimes=None):
  global CountedLines
  for Line in MainFileLines:
    CountedLines += 1
    Currenteditedvar = None
    CopyOfLine = Line


    if CopyOfLine[:4] == "var=" and CopyOfLine not in VariableDB:
      Word = CopyOfLine.find('>')
      Word = CopyOfLine[Word+1:]
      VariableDB.append(str(CopyOfLine))
    
    elif CopyOfLine[:5] == "func>":
      FuncDB.append(CopyOfLine)
    
    elif CopyOfLine[:9] == "func.run(":
      for possiblee in FuncDB: 
          if possiblee[5:].strip() == CopyOfLine[9:].strip():
            r = CopyOfLine.find('{')
            for poss in FuncLines:
              if poss[:7] == "print(.":
                print(poss[7:])
              if poss[:6] == "print(" and not poss[:7] == "print(.":
                print(poss[6:])
              if poss[:20] == "httpconnection.send(":
                      Comma = poss.find(',')
                      Par = poss.find('(')
                      Par2 = poss.find(')')
                      Token = poss[Par+1:Comma]
                      Data = poss[Comma+1:Par2]
                      realData = {
                        'content': Data
                      }
                      requests.post(Token, json=realData)
        

    elif CopyOfLine[:7] == "print(.":
      ree = CopyOfLine.find('[')
      ree2 = CopyOfLine.find('{')
      if CopyOfLine[ree:ree+1].strip() == "[":
        numb = CopyOfLine.find('[')
        for Possiblee in FuncDB:  
          if Possiblee[5:].strip() == CopyOfLine[numb+1:].strip():
            FuncLines.append(CopyOfLine[:numb])
        continue
      elif CopyOfLine[ree2:ree2+1].strip() == "{":
        for Possiblee in IfStateDB:
          if Possiblee[Possiblee.find('>')+1:].strip() == CopyOfLine[ree2+1:].strip():

            Word = Possiblee.find('>')
            WordName = Possiblee[4:Word]
            Word = Possiblee[Word+1:]
            r = CopyOfLine.find('(')
            r1 = CopyOfLine.find('{')


            IfStateLines.append(CopyOfLine[:r1])
      else:
        print(CopyOfLine[7:])
        continue
    
    elif CopyOfLine[:6] == "print(":
      ree = CopyOfLine.find('[')
      ree2 = CopyOfLine.find('{')
      if CopyOfLine[ree:ree+1].strip() == "[":
        for Possiblee in FuncDB:
          if Possiblee[5:].strip() == CopyOfLine[ree+1:].strip():
            for Possiblee in VariableDB:
              Word = Possiblee.find('>')
              WordName = Possiblee[4:Word]
              Word = Possiblee[Word+1:]
              r = CopyOfLine.find('[')
              if CopyOfLine[6:r].strip() == WordName.strip():
                FuncLines.append("print("+Word)

      elif CopyOfLine[ree2:ree2+1].strip() == "{":
        for Possiblee in IfStateDB:
          if Possiblee[Possiblee.find('>')+1:].strip() == CopyOfLine[ree2+1:].strip():
            for Possiblee in VariableDB:
              Word = Possiblee.find('>')
              WordName = Possiblee[4:Word]
              Word = Possiblee[Word+1:]
              r = CopyOfLine.find('(')
              r1 = CopyOfLine.find('{')
              if CopyOfLine[r+1:r1].strip() == WordName.strip():
                IfStateLines.append("print("+Word)
                print
      else:
        for Possiblee in VariableDB:
          Word = Possiblee.find('>')
          WordName = Possiblee[4:Word]
          Word = Possiblee[Word+1:]
          if CopyOfLine[6:].strip() == WordName.strip():
            print(Word)
            continue
    elif CopyOfLine[:12] == "ifstate.run(":
      for possiblee in IfStateDB:
        rr2 = possiblee.find('>')
        if possiblee[rr2+1:].strip() == CopyOfLine[12:].strip():
          for poss in IfStateLines:
            for pos in VariableDB:
              r = possiblee.find(':')
              r2 = possiblee.find('==') or possiblee.find('>=') or possiblee.find('<=')
              r3 = possiblee.find('>')
              rr = pos.find('=')
              rr2 = pos.find('>')
              if possiblee[3:r2].strip() == pos[rr+1:rr2].strip():
                if possiblee.find('=='):
                  if str(possiblee[r2+2:r3].strip()) == str(pos[rr2+1:].strip()):
                    if poss[:7] == "print(.":
                      print(poss[7:])
                    if poss[:6] == "print(" and not poss[:7] == "print(.":
                      print(poss[6:])
                    if poss[:20] == "httpconnection.send(":
                      Comma = poss.find(',')
                      Par = poss.find('(')
                      Par2 = poss.find(')')
                      Token = poss[Par+1:Comma]
                      Data = poss[Comma+1:Par2]
                      realData = {
                        'content': Data
                      }
                      requests.post(Token, json=realData)
                  else:
                    if IfElseLines == []:
                      return
                    else:
                      for e in IfElseLines:
                        x = e.find('[')
                        x1 = e.find('.')
                        x2 = e.find('(')
                        if e[x+1:x1+1].strip() == "print(.":
                          print(e[x1+1:])
                        if e[x+1:x2+1].strip() == "print(" and not e[x+1:x1+1].strip() == "print(.":
                          print(e[x2+1:])


                elif possiblee.find('>='):
                    if int(possiblee[r2+2:r3].strip()) >= int(pos[rr2+1:].strip()):
                      if poss[:7] == "print(.":
                        print(poss[7:])
                      if poss[:6] == "print(" and not poss[:7] == "print(.":
                        print(poss[6:])
                elif possiblee.find('<='):
                  if int(possiblee[r2+2:r3].strip()) <= int(pos[rr2+1:].strip()):
                      if poss[:7] == "print(.":
                        print(poss[7:])
                      if poss[:6] == "print(" and not poss[:7] == "print(.":
                        print(poss[6:])
        else:
          print("IfState error: Line", CountedLines)
      
    elif CopyOfLine[:7] == "ifelse>":
      for posiblee in IfStateDB:
        r = posiblee.find('>')
        r2 = CopyOfLine.find('[')
        r3 = CopyOfLine.find('>')
        if posiblee[r:].strip() == CopyOfLine[r3:r2].strip():
          IfElseLines.append(CopyOfLine)

    elif CopyOfLine[:3] == "if:":
        for Possiblee in VariableDB:
          r = CopyOfLine.find("==")
          r1 = Possiblee.find('>')
          if CopyOfLine[3:r].strip() == Possiblee[4:r1].strip():
            IfStateDB.append(str(CopyOfLine))
            continue 

    elif CopyOfLine == "clearmemory(":
      VariableDB.clear()
      FuncDB.clear()
      FuncLines.clear()
      IfStateDB.clear()
      IfStateLines.clear()
      IfElseLines.clear()
      print("Memory cleared..")

    elif CopyOfLine[:8] == "install>":
      if CopyOfLine[8:].strip() == "HttpConnection":
        ServicesImported.append("HttpConnection")

    elif CopyOfLine[:20] == "httpconnection.send(":
      if ServicesImported == []:
        print("HttpConnection not installed..")
      else:
        for x in ServicesImported:
          if x == "HttpConnection":
            Comma = CopyOfLine.find(',')
            Par = CopyOfLine.find('(')
            Par2 = CopyOfLine.find(')')
            if CopyOfLine[Par2+1:].strip() == "":
              Token = CopyOfLine[Par+1:Comma]
              Data = CopyOfLine[Comma+1:Par2]
              realData = {
                'content': Data
              }
              requests.post(Token, json=realData)
              return
            elif CopyOfLine[Par2+1:Par2+2].strip() == "[":
              for x1 in FuncDB:
                if CopyOfLine[Par2+2:].strip() == x1[x1.find('>')+1:].strip():
                  FuncLines.append(CopyOfLine[:Par2+1])
            else:
              for x1 in IfStateDB:
                if CopyOfLine[Par2+2:].strip() == x1[x1.find('>')+1:].strip():
                  IfStateLines.append(CopyOfLine[:Par2+1])
          else:
            print("HttpConnection not installed..")

    elif CopyOfLine.strip() == "":
      CountedLines -= 1
      continue
    elif CopyOfLine[:1] == "#":
      CountedLines -= 1
      continue
    else:
      print("Syntax error: Line", CountedLines)

  if CountedLines == 1:
    print("\nProgram Runned,", str(CountedLines), "line executed.")
  elif CountedLines == 0:
    print("\nProgram Runned,", str(CountedLines), "lines executed.")
  else:
    print("\nProgram Runned,", str(CountedLines), "lines executed.")
  CountedLines =0

Execute_File()